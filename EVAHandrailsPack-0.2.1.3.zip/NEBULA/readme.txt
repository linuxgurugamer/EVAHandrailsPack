NEBULA station parts by Krasimir.

Installation:

Unzip the contents of the zip file directly to the KSP GameData folder, so the NEBULA folder ends up in the GameData catalog. For example: c:\games\KSP_win\GameData\NEBULA.
If you want to use the flags - open the Flags directory and copy the files in \GameData\Squad\Flags.

License: CC BY-NC-SA 3.0